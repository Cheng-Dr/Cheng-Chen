#include "ShiftRegister.h"
#include "stm32f4xx_hal.h"

// Internal buffer (optional, not strictly needed)
static uint8_t shiftBuffer = 0;
static uint8_t shiftIndex = 0;

/**
 * @brief Shift in one bit to the shift register.
 */
void ShiftRegisterValue(uint16_t value)
{
    if (shiftIndex >= 8) return;

    if (value)
        shiftBuffer |= (1 << (7 - shiftIndex));
    else
        shiftBuffer &= ~(1 << (7 - shiftIndex));

    HAL_GPIO_WritePin(SHIFT_REG_SER_PORT, SHIFT_REG_SER_PIN, value ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(SHIFT_REG_CLK_PORT, SHIFT_REG_CLK_PIN, GPIO_PIN_SET);
    HAL_GPIO_WritePin(SHIFT_REG_CLK_PORT, SHIFT_REG_CLK_PIN, GPIO_PIN_RESET);

    shiftIndex++;
}

/**
 * @brief Shift a full 8-bit byte to the shift register.
 */
void ShiftRegister_WriteByte(uint8_t val)
{
    for (int i = 7; i >= 0; i--) {
        ShiftRegisterValue((val >> i) & 0x01);
    }
}

/**
 * @brief Clear all outputs (all 0s).
 */
void ShiftRegister_ClearAll(void)
{
    shiftBuffer = 0;
    ShiftRegister_WriteByte(0x00);
    ShiftRegister_Latch();
}

/**
 * @brief Latch the shifted bits to the output.
 */
void ShiftRegister_Latch(void)
{
    HAL_GPIO_WritePin(SHIFT_REG_LATCH_PORT, SHIFT_REG_LATCH_PIN, GPIO_PIN_SET);
    HAL_GPIO_WritePin(SHIFT_REG_LATCH_PORT, SHIFT_REG_LATCH_PIN, GPIO_PIN_RESET);
    shiftIndex = 0;
}
