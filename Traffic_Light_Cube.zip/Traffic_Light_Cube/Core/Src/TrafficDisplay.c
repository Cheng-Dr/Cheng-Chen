#include "TrafficDisplay.h"
#include "ShiftRegister.h"
#include "cmsis_os.h"

extern uint16_t g_light_phase;  // 0 = Red, 1 = Green, 2 = Yellow
extern SemaphoreHandle_t xMutexLight;

#define LED_COUNT 8

void TrafficDisplayTask(void *pvParameters)
{
    uint8_t active_led = 0;
    uint8_t left_blink_state = 0;
    uint16_t light_phase = 0;

    ShiftRegister_ClearAll();

    while (1)
    {
        // Get traffic light phase
        if (xSemaphoreTake(xMutexLight, pdMS_TO_TICKS(10)) == pdTRUE)
        {
            light_phase = g_light_phase;
            xSemaphoreGive(xMutexLight);
        }

        if (light_phase == 0)  // 🔴 RED: Left LEDs ON, Right OFF
        {
            ShiftRegister_WriteByte(0xF0);  // 11110000
            ShiftRegister_Latch();
            active_led = 0;
            left_blink_state = 0;
            vTaskDelay(pdMS_TO_TICKS(500));
        }
        else if (light_phase == 1)  // 🟢 GREEN: Blink 1-by-1 fast loop
        {
            ShiftRegister_WriteByte(1 << active_led);
            ShiftRegister_Latch();
            vTaskDelay(pdMS_TO_TICKS(100));

            ShiftRegister_WriteByte(0x00);
            ShiftRegister_Latch();
            vTaskDelay(pdMS_TO_TICKS(30));

            active_led = (active_led + 1) % LED_COUNT;
        }
        else if (light_phase == 2)  // 🟡 YELLOW: Left blink, Right OFF
        {
            left_blink_state ^= 0xF0;  // Toggle 11110000
            ShiftRegister_WriteByte(left_blink_state);
            ShiftRegister_Latch();
            vTaskDelay(pdMS_TO_TICKS(400));
        }
    }
}
