#include "TrafficLight.h"
#include "main.h"
#include "cmsis_os.h"
#include "stdio.h"

// 灯光状态共享变量
extern uint16_t g_light_colour;

/**
 * @brief Traffic Light Control Task (Red → Green → Yellow → loop)
 *        Implements logic using vTaskDelay instead of software timers.
 */
void TrafficLightTask(void *argument)
{
    for (;;)
    {
        // --------------------------
        // 🔴 Red Light
        HAL_GPIO_WritePin(TRAFFIC_LIGHT_PORT, TRAFFIC_LIGHT_GREEN_PIN, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(TRAFFIC_LIGHT_PORT, TRAFFIC_LIGHT_YELLOW_PIN, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(TRAFFIC_LIGHT_PORT, TRAFFIC_LIGHT_RED_PIN, GPIO_PIN_SET);
        g_light_colour = 0;  // 0 = Red
        printf("Traffic Light: RED\n");
        vTaskDelay(pdMS_TO_TICKS(5000)); // 红灯持续 5 秒

        // --------------------------
        // 🟢 Green Light
        HAL_GPIO_WritePin(TRAFFIC_LIGHT_PORT, TRAFFIC_LIGHT_RED_PIN, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(TRAFFIC_LIGHT_PORT, TRAFFIC_LIGHT_GREEN_PIN, GPIO_PIN_SET);
        g_light_colour = 1;  // 1 = Green
        printf("Traffic Light: GREEN\n");
        vTaskDelay(pdMS_TO_TICKS(10000)); // 绿灯持续 10 秒

        // --------------------------
        // 🟡 Yellow Light
        HAL_GPIO_WritePin(TRAFFIC_LIGHT_PORT, TRAFFIC_LIGHT_GREEN_PIN, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(TRAFFIC_LIGHT_PORT, TRAFFIC_LIGHT_YELLOW_PIN, GPIO_PIN_SET);
        g_light_colour = 0;  // 黄灯仍属于“禁止通行”阶段
        printf("Traffic Light: YELLOW\n");
        vTaskDelay(pdMS_TO_TICKS(2000)); // 黄灯持续 2 秒
    }
}
