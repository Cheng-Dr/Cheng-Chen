#include "main.h"
#include "TrafficLight.h"
#include "TrafficFlow.h"
#include "TrafficCreator.h"
#include "TrafficDisplay.h"
#include "ShiftRegister.h"
#include "STMRTOSconfig.h"
#include "cmsis_os.h"
#include "adc.h"  // CubeMX 生成的 ADC 初始化接口

/* Global Variables */
uint16_t g_light_phase = 0;    // 0 = Red, 1 = Green, 2 = Yellow
uint16_t g_light_colour = 0;   // 0 = Red, 1 = Green
uint16_t g_flowrate = 0;
uint16_t g_car_value = 0;


/* FreeRTOS mutex handles */
SemaphoreHandle_t xMutexFlow;
SemaphoreHandle_t xMutexLight;
SemaphoreHandle_t xMutexCars;


/* ADC Handle (由 CubeMX 自动生成) */
extern ADC_HandleTypeDef hadc1;

/*-----------------------------------------------------------*/
void HardwareInit(void);
void ADCTestTask(void *pvParameters);
void ShiftTestTask(void *pvParameters);

int main(void)
{
    HAL_Init();
    SystemClock_Config();         // 确保在 main.h 中声明
    MX_ADC1_Init();               // 由 CubeMX 生成，用于初始化 hadc1

    HardwareInit();

    // Create mutexes
    xMutexFlow  = xSemaphoreCreateMutex(); xSemaphoreGive(xMutexFlow);
    xMutexLight = xSemaphoreCreateMutex(); xSemaphoreGive(xMutexLight);
    xMutexCars  = xSemaphoreCreateMutex(); xSemaphoreGive(xMutexCars);

    // Create tasks
    xTaskCreate(TrafficFlowAdjustmentTask, "FlowAdjust", 128, NULL, TRAFFIC_FLOW_TASK_PRIORITY, NULL);
    xTaskCreate(TrafficCreatorTask,        "Creator",    128, NULL, TRAFFIC_CREATE_TASK_PRIORITY, NULL);
    xTaskCreate(TrafficLightTask,          "Light",      128, NULL, TRAFFIC_LIGHT_TASK_PRIORITY, NULL);
    xTaskCreate(TrafficDisplayTask,        "Display",    128, NULL, TRAFFIC_DISPLAY_TASK_PRIORITY, NULL);
    // 可选测试任务：
    // xTaskCreate(ADCTestTask,              "ADC",        128, NULL, osPriorityLow, NULL);
    // xTaskCreate(ShiftTestTask,           "Shift",      128, NULL, osPriorityLow, NULL);

    // 初始状态：绿灯亮
    g_light_colour = 0;
    g_light_phase = 0;
    HAL_GPIO_WritePin(TRAFFIC_LIGHT_PORT, TRAFFIC_LIGHT_GREEN_PIN, GPIO_PIN_SET);
    //g_light_colour = 1;

    vTaskStartScheduler();
    while (1);
}

void SystemClock_Config(void) {
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

    __HAL_RCC_PWR_CLK_ENABLE();
    __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE2);

    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
    RCC_OscInitStruct.HSIState = RCC_HSI_ON;
    RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
    RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
    HAL_RCC_OscConfig(&RCC_OscInitStruct);

    RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
                                | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
    RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

    HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0);
}

void HardwareInit(void)
{
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();
    __HAL_RCC_GPIOC_CLK_ENABLE();
    __HAL_RCC_GPIOD_CLK_ENABLE();
    __HAL_RCC_GPIOE_CLK_ENABLE();

    GPIO_InitTypeDef GPIO_InitStruct = {0};

    // Shift Register 1
    GPIO_InitStruct.Pin = SHIFT_REG_1_PIN | SHIFT_REG_CLK_1_PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(SHIFT_REG_1_PORT, &GPIO_InitStruct);

    // Shift Register 2
    GPIO_InitStruct.Pin = SHIFT_REG_2_PIN | SHIFT_REG_CLK_2_PIN;
    HAL_GPIO_Init(SHIFT_REG_2_PORT, &GPIO_InitStruct);

    // Traffic Light LEDs
    GPIO_InitStruct.Pin = TRAFFIC_LIGHT_RED_PIN | TRAFFIC_LIGHT_YELLOW_PIN | TRAFFIC_LIGHT_GREEN_PIN;
    HAL_GPIO_Init(TRAFFIC_LIGHT_PORT, &GPIO_InitStruct);
}

void ADCTestTask(void *pvParameters)
{
    while (1)
    {
        HAL_ADC_Start(&hadc1);
        HAL_ADC_PollForConversion(&hadc1, HAL_MAX_DELAY);
        uint16_t adc_value = HAL_ADC_GetValue(&hadc1);
        printf("ADC Value: %d\n", adc_value);
        vTaskDelay(pdMS_TO_TICKS(500));
    }
}

void ShiftTestTask(void *pvParameters)
{
    while (1)
    {
        ShiftRegisterValuePreLight(true);  vTaskDelay(pdMS_TO_TICKS(500));
        ShiftRegisterValuePreLight(true);  vTaskDelay(pdMS_TO_TICKS(500));
        ShiftRegisterValuePreLight(false); vTaskDelay(pdMS_TO_TICKS(500));
        ShiftRegisterValuePreLight(false); vTaskDelay(pdMS_TO_TICKS(500));
    }
}

void Error_Handler(void) {
    __disable_irq();
    while (1) {
        // 可加 LED 闪烁调试
    }
}

/*-----------------------------------------------------------*/
/* FreeRTOS 钩子函数（可选） */

void vApplicationMallocFailedHook(void) {
    while (1);
}

void vApplicationStackOverflowHook(TaskHandle_t xTask, char *pcTaskName) {
    (void)xTask; (void)pcTaskName;
    while (1);
}

void vApplicationIdleHook(void)
{
    volatile size_t xFreeStackSpace = xPortGetFreeHeapSize();
    if (xFreeStackSpace > 100) {
        // 可以调低 configTOTAL_HEAP_SIZE
    }
}


