#include "TrafficFlow.h"
#include "cmsis_os.h"
#include "main.h"
#include <stdio.h>
#include <stdlib.h>
#include "adc.h"

/* 外部变量：ADC 句柄、全局共享变量、互斥锁 */

extern uint16_t g_flowrate;
extern SemaphoreHandle_t xMutexFlow;

/*
 * TrafficFlowAdjustmentTask
 * -------------------------
 * Reads ADC value from potentiometer and updates flowrate (0–7)
 * in response to change. Shared via g_flowrate protected by xMutexFlow.
 */
void TrafficFlowAdjustmentTask(void *pvParameters)
{
    uint16_t adc_value = 0;
    uint16_t speed_adc_value = 0;
    uint16_t current_speed_value = 0;
    uint16_t change_in_speed;

    while (1)
    {
        printf("FlowAdjustmentTask: Starting ADC conversion for new flowrate.\n");

        // 启动 ADC 转换
        HAL_ADC_Start(&hadc1);
        HAL_ADC_PollForConversion(&hadc1, HAL_MAX_DELAY); // 等待转换完成
        adc_value = HAL_ADC_GetValue(&hadc1);

        // 映射到 0-7 的区间
        speed_adc_value = adc_value / 512;
        if (speed_adc_value > 7)
        {
            speed_adc_value = 7;
        }

        change_in_speed = abs(speed_adc_value - current_speed_value);

        if (change_in_speed != 0)
        {
            current_speed_value = speed_adc_value;

            if (xSemaphoreTake(xMutexFlow, pdMS_TO_TICKS(10)) == pdTRUE)
            {
                g_flowrate = speed_adc_value;
                xSemaphoreGive(xMutexFlow);
                printf("FlowAdjustmentTask: Flowrate = %u, ADC = %u\n", speed_adc_value, adc_value);
            }
            else
            {
                printf("FlowTask: xMutexFlow unavailable\n");
            }
        }

        vTaskDelay(pdMS_TO_TICKS(200));
    }
}
