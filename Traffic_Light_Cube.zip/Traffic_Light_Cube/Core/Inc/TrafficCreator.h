#ifndef __TRAFFICCREATOR_H_
#define __TRAFFICCREATOR_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "STMRTOSconfig.h"

/*
 * Task responsible for generating traffic car patterns based on flowrate.
 * Flowrate is determined by TrafficFlow task and shared via g_flowrate.
 */
void TrafficCreatorTask(void *pvParameters);

#ifdef __cplusplus
}
#endif

#endif /* __TRAFFICCREATOR_H_ */
