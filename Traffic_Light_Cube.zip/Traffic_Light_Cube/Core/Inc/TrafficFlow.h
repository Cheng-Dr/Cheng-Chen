#ifndef __TRAFFICFLOW_H_
#define __TRAFFICFLOW_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "STMRTOSconfig.h"

/**
 * @brief Traffic flow adjustment task
 *
 * Reads ADC value from a potentiometer, maps it to a flow rate (0~7),
 * and updates the global variable `g_flowrate` accordingly.
 * Only updates when the flowrate changes.
 */
void TrafficFlowAdjustmentTask(void *pvParameters);

#ifdef __cplusplus
}
#endif

#endif /* __TRAFFICFLOW_H_ */
