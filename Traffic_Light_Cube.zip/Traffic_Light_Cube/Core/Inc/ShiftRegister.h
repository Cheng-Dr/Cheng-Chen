#ifndef SHIFTREGISTER_H_
#define SHIFTREGISTER_H_

#include "stm32f4xx_hal.h"

/* === Pin definitions for single 74HC595 === */
#define SHIFT_REG_SER_PORT   GPIOE
#define SHIFT_REG_SER_PIN    GPIO_PIN_5

#define SHIFT_REG_CLK_PORT   GPIOE
#define SHIFT_REG_CLK_PIN    GPIO_PIN_3

#define SHIFT_REG_LATCH_PORT GPIOE
#define SHIFT_REG_LATCH_PIN  GPIO_PIN_4

/* === Function prototypes === */
void ShiftRegisterValue(uint16_t value);
void ShiftRegister_WriteByte(uint8_t val);
void ShiftRegister_ClearAll(void);
void ShiftRegister_Latch(void);

#endif /* SHIFTREGISTER_H_ */
