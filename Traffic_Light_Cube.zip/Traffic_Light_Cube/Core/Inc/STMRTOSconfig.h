#ifndef STMRTOSCONFIG_H_
#define STMRTOSCONFIG_H_

/* Standard C includes */
#include <stdint.h>
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

/* STM32 HAL + FreeRTOS includes */
#include "main.h"               // 包含 HAL 和 GPIO 引脚定义
#include "FreeRTOS.h"
#include "queue.h"
#include "semphr.h"
#include "task.h"
#include "timers.h"

/* ------------------ Pinout Defines (HAL Style) ------------------ */

// ADC 接口
#define ADC_PORT                 GPIOC
#define ADC_PIN                  GPIO_PIN_1  // ✅ HAL 风格

// Shift Register #1
#define SHIFT_REG_1_PORT         GPIOE
#define SHIFT_REG_1_PIN          GPIO_PIN_5
#define SHIFT_REG_CLK_1_PIN      GPIO_PIN_3

// Shift Register #2
#define SHIFT_REG_2_PORT         GPIOC
#define SHIFT_REG_2_PIN          GPIO_PIN_15
#define SHIFT_REG_CLK_2_PIN      GPIO_PIN_14

// Traffic Light LEDs
#define TRAFFIC_LIGHT_PORT       GPIOD
#define TRAFFIC_LIGHT_RED_PIN    GPIO_PIN_6
#define TRAFFIC_LIGHT_YELLOW_PIN GPIO_PIN_4
#define TRAFFIC_LIGHT_GREEN_PIN  GPIO_PIN_2

/* ------------------ FreeRTOS Task Priorities ------------------ */
#define TRAFFIC_FLOW_TASK_PRIORITY      ( tskIDLE_PRIORITY + 1 )
#define TRAFFIC_CREATE_TASK_PRIORITY    ( tskIDLE_PRIORITY + 2 )
#define TRAFFIC_LIGHT_TASK_PRIORITY     ( tskIDLE_PRIORITY + 2 )
#define TRAFFIC_DISPLAY_TASK_PRIORITY   ( tskIDLE_PRIORITY )

/* ------------------ Shared Global Variables ------------------ */
extern uint16_t g_flowrate;
extern uint16_t g_light_colour;
extern uint16_t g_car_value;

/* ------------------ FreeRTOS Mutexes ------------------ */
extern SemaphoreHandle_t xMutexFlow;
extern SemaphoreHandle_t xMutexLight;
extern SemaphoreHandle_t xMutexCars;

#endif /* STMRTOSCONFIG_H_ */
