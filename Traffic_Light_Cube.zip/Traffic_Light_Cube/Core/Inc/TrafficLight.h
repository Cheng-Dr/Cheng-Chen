#ifndef __TRAFFICLIGHT_H_
#define __TRAFFICLIGHT_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "STMRTOSconfig.h"

/* ---------------- Timer Callbacks ---------------- */
/**
 * @brief Callback for green light timer (transition to yellow)
 */
void vGreenLightTimerCallback(TimerHandle_t xTimer);

/**
 * @brief Callback for yellow light timer (transition to red)
 */
void vYellowLightTimerCallback(TimerHandle_t xTimer);

/**
 * @brief Callback for red light timer (transition to green)
 */
void vRedLightTimerCallback(TimerHandle_t xTimer);

/* ---------------- Main Light Task ---------------- */
/**
 * @brief Traffic light logic controller task
 *
 * Controls software timers and LED behavior based on flowrate
 */
void TrafficLightTask(void *pvParameters);

/* ---------------- Timer Handles (extern) ---------------- */
extern TimerHandle_t xRedLightSoftwareTimer;
extern TimerHandle_t xYellowLightSoftwareTimer;
extern TimerHandle_t xGreenLightSoftwareTimer;

#ifdef __cplusplus
}
#endif

#endif /* __TRAFFICLIGHT_H_ */
