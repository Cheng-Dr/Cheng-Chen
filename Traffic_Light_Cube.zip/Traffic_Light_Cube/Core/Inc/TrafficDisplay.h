#ifndef __TRAFFICDISPLAY_H_
#define __TRAFFICDISPLAY_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "ShiftRegister.h"
#include "STMRTOSconfig.h"

/**
 * @brief Task to display traffic flow on shift registers
 *
 * This task uses car value (from TrafficCreator) and light status
 * (from TrafficLight) to simulate traffic flow with 8-step shift registers.
 */
void TrafficDisplayTask(void *pvParameters);

#ifdef __cplusplus
}
#endif

#endif /* __TRAFFICDISPLAY_H_ */
